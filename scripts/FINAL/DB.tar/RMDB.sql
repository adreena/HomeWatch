DROP TABLE IF EXISTS `Earned_Achievements`,`Building`,`Achievements`,`Resident`,`Users`,`Roles`;

CREATE TABLE IF NOT EXISTS `Roles` (
  `Role_ID` int(11) NOT NULL,
  `Role` varchar(30) NOT NULL,
  PRIMARY KEY (`Role_ID`)
);

INSERT INTO `Roles` (`Role_ID`, `Role`) VALUES
(1, 'DEV'),
(2, 'ADMIN'),
(3, 'MANAGER'),
(4, 'ENGINEER'),
(5, 'RESIDENT');

CREATE TABLE IF NOT EXISTS `Users` (
  `User_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(30) NOT NULL,
  `PW_Hash` varchar(255) NOT NULL,
  `Role_ID` int(11) NOT NULL,
  `Email` varchar(255) NOT NULL,
  Reset_Token varchar (32)DEFAULT NULL,
  PRIMARY KEY (`User_ID`),
  UNIQUE KEY `Username` (`Username`),
  UNIQUE KEY `Email` (`Email`),
  KEY `Role_ID` (`Role_ID`)
);

INSERT INTO `Users` (`User_ID`, `Username`, `PW_Hash`, `Role_ID`, `Email`, `Reset_Token`) VALUES
(1, 'root', '$2y$10$of7j4JQG7j5HSmDyYCTFfOQGKy6Nm8QLaZs9iWpIfCBrmRqUROzfe', 2, 'nikolaidis@ualberta.ca', '');

CREATE TABLE IF NOT EXISTS `Achievements` (
  `Achievement_ID` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Description` varchar(100) DEFAULT NULL,
  `Enabled_Icon` varchar(100) DEFAULT NULL,
  `Disabled_Icon` varchar(100) DEFAULT NULL,
  `Points` int(11) DEFAULT NULL,
  PRIMARY KEY (`Achievement_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `Achievements` (`Achievement_ID`, `Name`, `Description`, `Enabled_Icon`, `Disabled_Icon`, `Points`) VALUES
(1, 'water_under_x', 'Maintain water usage under x for a month!', 'water_under_x.png', 'no_water_under_x.png', 100),
(2, 'elec_under_x', 'Maintain electricity usage under x for a month!', 'elec_under_x.png', 'no_elec_under_x.png', 100),
(3, 'healthy_humidity', 'Maintain healthy levels of humidity for a month!', 'healthy_humidity.png', 'no_healthy_humidity.png', 100),
(4, 'healthy_co2', 'Maintain healthy levels of CO2 for a month!', 'healthy_co2.png', 'no_healthy_co2.png', 100),
(5, 'low_temp', 'Maintain indoor temperatures under 20 degrees Celsius for a week!', 'low_temp.png', 'no_low_temp.png', 100),
(6, 'decrease_water', 'Decrease water usage by 10% in one month!', 'decrease_water.png', 'no_decrease_water.png', 100),
(7, 'decrease_elec', 'Decrease electricity usage by 10% in one month!', 'decrease_elec.png', 'no_decrease_elec.png', 100);

CREATE TABLE IF NOT EXISTS `Resident` (
  `Resident_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Username` varchar(30) NOT NULL,
  `Room_Number` int(11) NOT NULL,
  `Location` varchar(100) NOT NULL,
  `Points` int(11) DEFAULT NULL,
  `Room_Status` varchar(10) DEFAULT NULL,
  `Score` int(11) DEFAULT NULL,
  PRIMARY KEY (`Resident_ID`),
  FOREIGN KEY (Username) REFERENCES Users(Username)ON DELETE CASCADE ON UPDATE CASCADE
) ;

INSERT INTO `Resident` (`Resident_ID`, `Name`, `Username`, `Room_Number`, `Location`, `Points`, `Room_Status`, `Score`) VALUES
(1, 'TEST', 'tsung', 1212, 'NE', 2323, 'TEST', 0),
(2, 'resident1', 'resident1', 413, 'SW', 123, 'Occupied', 0),
(3, 'Mr. Popo', 'test2', 42, 'NE', NULL, 'Occupied', NULL);


CREATE TABLE IF NOT EXISTS `Earned_Achievements` (
  Resident_ID int NOT NULL,
  Achievement_ID int NOT NULL,
  Date_Earned varchar(100) DEFAULT NULL,
  PRIMARY KEY (Resident_ID,Achievement_ID),
  FOREIGN KEY (Resident_ID) REFERENCES Resident(Resident_ID)ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (Achievement_ID) REFERENCES Achievements(Achievement_ID)ON DELETE CASCADE ON UPDATE CASCADE 
);


CREATE TABLE IF NOT EXISTS `Building` (
  `Building_ID` int(11) NOT NULL,
  `Resident_ID` int(11) NOT NULL,
  `Building` varchar(100) NOT NULL,
  `Floor` varchar(100) NOT NULL,
  `Orientation` varchar(100) NOT NULL,
  `Layout` varchar(100) NOT NULL,
  PRIMARY KEY (`Building_ID`,`Resident_ID`),
  FOREIGN KEY (Resident_ID) REFERENCES Resident(Resident_ID)ON DELETE CASCADE ON UPDATE CASCADE
) ;

INSERT INTO `Building` (`Building_ID`, `Resident_ID`, `Building`, `Floor`, `Orientation`, `Layout`) VALUES
(1, 1, 'Windsor', '4', 'NW', 'A');



DROP VIEW IF EXISTS `V_Achievements`;
CREATE TABLE IF NOT EXISTS `V_Achievements` (
`Name` varchar(100)
,`Description` varchar(100)
,`Date_Earned` varchar(100)
,`Points` int(11)
,`Disabled_Icon` varchar(100)
,`Enabled_Icon` varchar(100)
,`Resident_ID` int(11)
);






DROP TABLE IF EXISTS `V_Achievements`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `V_Achievements` AS select `A`.`Name` AS `Name`,`A`.`Description` AS `Description`,`B`.`Date_Earned` AS `Date_Earned`,`A`.`Points` AS `Points`,`A`.`Disabled_Icon` AS `Disabled_Icon`,`A`.`Enabled_Icon` AS `Enabled_Icon`,`B`.`Resident_ID` AS `Resident_ID` from (`Achievements` `A` join `Earned_Achievements` `B`) where (`A`.`Achievement_ID` = `B`.`Achievement_ID`);
