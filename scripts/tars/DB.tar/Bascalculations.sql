DROP Function IF EXISTS EQ2_part1;
DELIMITER $$
CREATE Function EQ2_part1(
		tsfrom VARCHAR(16),
		tsto VARCHAR(16) ) 
		RETURNS  float
BEGIN
DECLARE P110,P120,HPx10,HPx20,HPx30,HPx40,cop_heat_pump FLOAT;
DECLARE P11,P12,HPx1,HPx2,HPx3,HPx4 FLOAT;
SELECT AVG(`P-1-1`),
       AVG(`P-1-2`),
       AVG(`HP1`),
       AVG(`HP2`),
       AVG(`HP3`),
       AVG(`HP4`)
       INTO P110,P120,HPx10,HPx20,HPx30,HPx40 from bas_el_energy 
where date_format(ts,'%Y-%m-%d %H:%i') = tsfrom;

SELECT AVG(`P-1-1`),
       AVG(`P-1-2`),
       AVG(`HP1`),
       AVG(`HP2`),
       AVG(`HP3`),
       AVG(`HP4`)
       INTO P11,P12,HPx1,HPx2,HPx3,HPx4 from bas_el_energy 
where date_format(ts,'%Y-%m-%d %H:%i') = tsto;

set cop_heat_pump=(
                    (P11+P12+HPx1+HPx2+HPx3+HPx4)-
                    (P110+P120+HPx10+HPx20+HPx30+HPx40)
                  )/3600000;
return cop_heat_pump;
END $$


DELIMITER ;


DROP Function IF EXISTS EQ2_part2;

DELIMITER $$

CREATE Function EQ2_Part2(
     tsfrom VARCHAR(16)
  ,  tsto   VARCHAR(16) ) 
      Returns FLOAT 

BEGIN
DECLARE Hours,Cop_heat Float;
DECLARE SHTS,P7_1,P8,P2_1,P2_2,P2_3,P2_4,P4_1,P4_2,BLR_1,BLR_2,P3_1,P3_2 FLOAT;

Select (TIMESTAMPDIFF( MINUTE ,  tsfrom,  tsto )/60) INTO Hours;
Select (111.55*Hours*1*.001) INTO SHTS;
Select (714*Hours*1*.001) INTO P7_1;

Select 75.9*Hours*.001*( 
       AVG(BO_P8_1_DHR_Hx_EN)+
       AVG(BO_P8_2_DHR_Hx_EN)+
       AVG(BO_P8_3_DHR_Hx_EN)+
       AVG(BO_P8_4_DHR_Hx_EN)+
       AVG(BO_P8_5_DHR_Hx_EN)+
       AVG(BO_P8_7_DHR_Hx_EN)+
       AVG(BO_P8_8_DHR_Hx_EN)+
       AVG(BO_P8_9_DHR_Hx_EN)+
       AVG(BO_P8_10_DHR_Hx_EN)+
       AVG(BO_P8_11_DHR_Hx_EN)+
       AVG(BO_P8_12_DHR_Hx_EN)) INTO P8 from bas_drains
       where date_format(ts,'%Y-%m-%d %H:%i') between tsfrom and tsto;

Select 785*Hours*.001*(AVG(BO_P2_1_Enable)),
       785*Hours*.001*(AVG(BO_P2_2_Enable)),
       785*Hours*.001*(AVG(BO_P2_3_Enable)),
       785*Hours*.001*(AVG(BO_P2_4_Enable))  INTO P2_1,P2_2,P2_3,P2_4 from bas_geothermal
       where date_format(ts,'%Y-%m-%d %H:%i') between tsfrom and tsto;


Select 870*Hours*.001*(AVG(BO_Blr_1_Enable)),
       870*Hours*.001*(AVG(BO_Blr_2_Enable)),
       324*Hours*.001*(AVG(BO_Blr_1_Enable)), 
       324*Hours*.001*(AVG(BO_Blr_2_Enable))
       INTO P4_1,P4_2,BLR_1,BLR_2 from bas_boiler_loop
	where date_format(ts,'%Y-%m-%d %H:%i') between tsfrom and tsto;

Select 2460*Hours*.00001*(AVG(AO_P3_VFD_Ctrl)), 
       2460*Hours*.00001*(AVG(AO_P3_2_VFD_Ctrl))
       INTO P3_1,P3_2 from bas_heating_loop
	where date_format(ts,'%Y-%m-%d %H:%i') between tsfrom and tsto;

set cop_heat = SHTS+P7_1+P8+P2_1+P2_2+P2_3+P2_4+P4_1+P4_2+BLR_1+BLR_2+P3_1+P3_2;
return cop_heat;
END $$

DELIMITER ;


DROP Function IF EXISTS Calc_Cop;

DELIMITER $$

CREATE Function Calc_Cop(
     tsfrom VARCHAR(16)
  , tsto   VARCHAR(16)
  ) Returns VARCHAR (1)
   

BEGIN
DECLARE P110,P120,HPx10,HPx20,HPx30,HPx40 FLOAT;
DECLARE P11,P12,HPx1,HPx2,HPx3,HPx4 FLOAT;
DECLARE Hours,NUM1,NUM2,NUM3,DOM1,DOM2,DOM3,COP1,COP2,COP3 Float;
DECLARE SHTS,P7_1,P8,P2_1,P2_2,P2_3,P2_4,P4_1,P4_2,BLR_1,BLR_2,P3_1,P3_2 FLOAT;

# Energy Values in GJ

Select (TIMESTAMPDIFF( MINUTE ,  tsfrom,  tsto )/60) INTO Hours;
Select SUM(Energy4),SUM(Energy4+Energy5+Energy6) INTO NUM1,NUM2 from Energy_Minute
       where date_format(ts,'%Y-%m-%d %H:%i') between tsfrom and tsto;

# Values are converted from WS to KWH by dividing by 3,600,000
# Consumption Geo Field+ Heat Pumps (KWH) From Time Stamp
SELECT AVG(`P-1-1`)/3600000,
       AVG(`P-1-2`)/3600000,
       AVG(`HP1`)/3600000,
       AVG(`HP2`)/3600000,
       AVG(`HP3`)/3600000,
       AVG(`HP4`)/3600000
       INTO P110,P120,HPx10,HPx20,HPx30,HPx40 from bas_el_energy 
where date_format(ts,'%Y-%m-%d %H:%i') = tsfrom;

# Consumption Geo Field+ Heat Pumps (KWH) To Time Stamp
SELECT AVG(`P-1-1`)/3600000,
       AVG(`P-1-2`)/3600000,
       AVG(`HP1`)/3600000,
       AVG(`HP2`)/3600000,
       AVG(`HP3`)/3600000,
       AVG(`HP4`)/3600000
       INTO P11,P12,HPx1,HPx2,HPx3,HPx4 from bas_el_energy 
where date_format(ts,'%Y-%m-%d %H:%i') = tsto;
# Schedule 2 Power usage (KWH)
# Solar 
Select (111.55*Hours*1*.001) INTO SHTS;
# DWHR
Select (714*Hours*1*.001) INTO P7_1;

Select 75.9*Hours*.001*( 
       AVG(BO_P8_1_DHR_Hx_EN)+
       AVG(BO_P8_2_DHR_Hx_EN)+
       AVG(BO_P8_3_DHR_Hx_EN)+
       AVG(BO_P8_4_DHR_Hx_EN)+
       AVG(BO_P8_5_DHR_Hx_EN)+
       AVG(BO_P8_7_DHR_Hx_EN)+
       AVG(BO_P8_8_DHR_Hx_EN)+
       AVG(BO_P8_9_DHR_Hx_EN)+
       AVG(BO_P8_10_DHR_Hx_EN)+
       AVG(BO_P8_11_DHR_Hx_EN)+
       AVG(BO_P8_12_DHR_Hx_EN)) INTO P8 from bas_drains
       where date_format(ts,'%Y-%m-%d %H:%i') between tsfrom and tsto;

# Heat Pumps Circulation
Select 785*Hours*.001*(AVG(BO_P2_1_Enable)),
       785*Hours*.001*(AVG(BO_P2_2_Enable)),
       785*Hours*.001*(AVG(BO_P2_3_Enable)),
       785*Hours*.001*(AVG(BO_P2_4_Enable))  INTO P2_1,P2_2,P2_3,P2_4 from bas_geothermal
       where date_format(ts,'%Y-%m-%d %H:%i') between tsfrom and tsto;

# Boilers
Select 870*Hours*.001*(AVG(BO_Blr_1_Enable)),
       870*Hours*.001*(AVG(BO_Blr_2_Enable)),
       324*Hours*.001*(AVG(BO_Blr_1_Enable)), 
       324*Hours*.001*(AVG(BO_Blr_2_Enable))
       INTO P4_1,P4_2,BLR_1,BLR_2 from bas_boiler_loop
	where date_format(ts,'%Y-%m-%d %H:%i') between tsfrom and tsto;

# Heating Loop
Select 2460*Hours*.00001*(AVG(AO_P3_VFD_Ctrl)), 
       2460*Hours*.00001*(AVG(AO_P3_2_VFD_Ctrl))
       INTO P3_1,P3_2 from bas_heating_loop
	where date_format(ts,'%Y-%m-%d %H:%i') between tsfrom and tsto;

# Calculations of COP1, COP2, and COP3 
set DOM1=((P11+P12+HPx1+HPx2+HPx3+HPx4)- (P110+P120+HPx10+HPx20+HPx30+HPx40))+SHTS+P7_1+P8+P2_1+P2_2+P2_3+P2_4;
set DOM2 = ((P11+P12+HPx1+HPx2+HPx3+HPx4)- (P110+P120+HPx10+HPx20+HPx30+HPx40))+SHTS

+P7_1+P8+P2_1+P2_2+P2_3+P2_4+P4_1+P4_2+BLR_1+BLR_2+P3_1+P3_2;
set DOM3 = ((HPx1+HPx2+HPx3+HPx4)- (HPx10+HPx20+HPx30+HPx40))+P2_1+P2_2+P2_3+P2_4;
set NUM3 = NUM1;
set COP1 = 0;
set COP2 = 0;
set COP3 = 0;

# Avoid Dividing by 0
IF DOM1 != 0 Then set COP1 = (NUM1*277.78)/DOM1;
END IF;
IF DOM2 != 0 Then set COP2 = (NUM2*277.78)/DOM2;
END IF;
IF DOM3 != 0 Then set COP3 = (NUM3*277.78)/DOM3;
END IF;
insert into COPCal values (COP1,COP2,COP3);

 return " ";
END $$

DELIMITER ;


DROP Function IF EXISTS calc_cop_test;

DELIMITER $$

CREATE Function calc_cop_test(
     tsfrom VARCHAR(16)
  , tsto   VARCHAR(16)
  ) Returns VARCHAR (1)
   

BEGIN
DECLARE P110,P120,HPx10,HPx20,HPx30,HPx40 FLOAT;
DECLARE P11,P12,HPx1,HPx2,HPx3,HPx4 FLOAT;
DECLARE Hours,NUM1,NUM2,NUM3,DOM1,DOM2,DOM3,COP1,COP2,COP3 Float;
DECLARE SHTS,P7_1,P8,P2_1,P2_2,P2_3,P2_4,P4_1,P4_2,BLR_1,BLR_2,P3_1,P3_2 FLOAT;

# Energy Values in GJ

Select (TIMESTAMPDIFF( MINUTE ,  tsfrom,  tsto )/60) INTO Hours;
Select SUM(Energy4),SUM(Energy4+Energy5+Energy6) INTO NUM1,NUM2 from Energy_Minute
       where date_format(ts,'%Y-%m-%d %H:%i') between tsfrom and tsto;

# Values are converted from WS to KWH by dividing by 3,600,000
# Consumption Geo Field+ Heat Pumps (KWH) From Time Stamp
SELECT AVG(`P-1-1`)/3600000,
       AVG(`P-1-2`)/3600000,
       AVG(`HP1`)/3600000,
       AVG(`HP2`)/3600000,
       AVG(`HP3`)/3600000,
       AVG(`HP4`)/3600000
       INTO P110,P120,HPx10,HPx20,HPx30,HPx40 from bas_el_energy 
where date_format(ts,'%Y-%m-%d %H:%i') = tsfrom;

# Consumption Geo Field+ Heat Pumps (KWH) To Time Stamp
SELECT AVG(`P-1-1`)/3600000,
       AVG(`P-1-2`)/3600000,
       AVG(`HP1`)/3600000,
       AVG(`HP2`)/3600000,
       AVG(`HP3`)/3600000,
       AVG(`HP4`)/3600000
       INTO P11,P12,HPx1,HPx2,HPx3,HPx4 from bas_el_energy 
where date_format(ts,'%Y-%m-%d %H:%i') = tsto;
# Schedule 2 Power usage (KWH)
# Solar 
Select (111.55*Hours*1*.001) INTO SHTS;
# DWHR
Select (714*Hours*1*.001) INTO P7_1;

Select 75.9*Hours*.001*( 
       AVG(BO_P8_1_DHR_Hx_EN)+
       AVG(BO_P8_2_DHR_Hx_EN)+
       AVG(BO_P8_3_DHR_Hx_EN)+
       AVG(BO_P8_4_DHR_Hx_EN)+
       AVG(BO_P8_5_DHR_Hx_EN)+
       AVG(BO_P8_7_DHR_Hx_EN)+
       AVG(BO_P8_8_DHR_Hx_EN)+
       AVG(BO_P8_9_DHR_Hx_EN)+
       AVG(BO_P8_10_DHR_Hx_EN)+
       AVG(BO_P8_11_DHR_Hx_EN)+
       AVG(BO_P8_12_DHR_Hx_EN)) INTO P8 from bas_drains
       where date_format(ts,'%Y-%m-%d %H:%i') between tsfrom and tsto;

# Heat Pumps Circulation
Select 785*Hours*.001*(AVG(BO_P2_1_Enable)),
       785*Hours*.001*(AVG(BO_P2_2_Enable)),
       785*Hours*.001*(AVG(BO_P2_3_Enable)),
       785*Hours*.001*(AVG(BO_P2_4_Enable))  INTO P2_1,P2_2,P2_3,P2_4 from bas_geothermal
       where date_format(ts,'%Y-%m-%d %H:%i') between tsfrom and tsto;

# Boilers
Select 870*Hours*.001*(AVG(BO_Blr_1_Enable)),
       870*Hours*.001*(AVG(BO_Blr_2_Enable)),
       324*Hours*.001*(AVG(BO_Blr_1_Enable)), 
       324*Hours*.001*(AVG(BO_Blr_2_Enable))
       INTO P4_1,P4_2,BLR_1,BLR_2 from bas_boiler_loop
	where date_format(ts,'%Y-%m-%d %H:%i') between tsfrom and tsto;

# Heating Loop
Select 2460*Hours*.00001*(AVG(AO_P3_VFD_Ctrl)), 
       2460*Hours*.00001*(AVG(AO_P3_2_VFD_Ctrl))
       INTO P3_1,P3_2 from bas_heating_loop
	where date_format(ts,'%Y-%m-%d %H:%i') between tsfrom and tsto;

	
# Calculations of COP1, COP2, and COP3 
set DOM1=((P11+P12+HPx1+HPx2+HPx3+HPx4)- (P110+P120+HPx10+HPx20+HPx30+HPx40))+SHTS+P7_1+P8+P2_1+P2_2+P2_3+P2_4;
set DOM2 = ((P11+P12+HPx1+HPx2+HPx3+HPx4)- (P110+P120+HPx10+HPx20+HPx30+HPx40))+SHTS

+P7_1+P8+P2_1+P2_2+P2_3+P2_4+P4_1+P4_2+BLR_1+BLR_2+P3_1+P3_2;
set DOM3 = ((HPx1+HPx2+HPx3+HPx4)- (HPx10+HPx20+HPx30+HPx40))+P2_1+P2_2+P2_3+P2_4;
set NUM3 = NUM1;
set COP1 = 0;
set COP2 = 0;
set COP3 = 0;

# Avoid Dividing by 0
IF DOM1 != 0 Then set COP1 = (NUM1*277.78)/DOM1;
END IF;
IF DOM2 != 0 Then set COP2 = (NUM2*277.78)/DOM2;
END IF;
IF DOM3 != 0 Then set COP3 = (NUM3*277.78)/DOM3;
END IF;
insert into anaylze values  (COP1,COP2,COP3,(P11-P110) ,(P12-P120)  ,(HPx1-HPx10)  ,(HPx2-HPx20)  ,(HPx3-HPx30)   ,(HPx4-HPx40),Hours 
 ,NUM1  ,NUM2 ,NUM3,DOM1 ,DOM2 ,DOM3,P7_1 ,P8 ,P2_1 ,P2_2 ,P2_3 ,P2_4 ,P4_1 ,P4_2 ,BLR_1 ,BLR_2 ,P3_1 ,P3_2 ,SHTS);
   
 return " ";
END $$

DELIMITER ;