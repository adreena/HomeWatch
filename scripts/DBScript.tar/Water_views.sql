CREATE OR REPLACE VIEW Water_Yearly 
							AS select `v0_water`.`Apt` AS `Apt`,
                            Max(`v0_water`.`Hot_Water`) - Min(`v0_water`.`Hot_Water`) AS `Hot_Water`,
                            Max(`v0_water`.`Total_Water`) - Min(`v0_water`.`Total_Water`) AS `Total_Water`,
							`v0_water`.`Year` AS `Year` 
							from `v0_water` group by `v0_water`.`Apt`,`v0_water`.`Year`;

CREATE OR REPLACE VIEW Water_Monthly 
							AS select `v0_water`.`Apt` AS `Apt`,
                              Max(`v0_water`.`Hot_Water`) - Min(`v0_water`.`Hot_Water`) AS `Hot_Water`,
                              Max(`v0_water`.`Total_Water`) - Min(`v0_water`.`Total_Water`) AS `Total_Water`,
							`v0_water`.`Year` AS `Year`,
							`v0_water`.`Month` AS `Month`
							from `v0_water` group by `v0_water`.`Apt`,`v0_water`.`Year`,`v0_water`.`month`;	
							
CREATE OR REPLACE VIEW Water_Weekly 
							AS select `v0_water`.`Apt` AS `Apt`,
                               Max(`v0_water`.`Hot_Water`) - Min(`v0_water`.`Hot_Water`) AS `Hot_Water`,
                            Max(`v0_water`.`Total_Water`) - Min(`v0_water`.`Total_Water`) AS `Total_Water`,
							`v0_water`.`Year` AS `Year`, 
							`v0_water`.`Week` AS `Week`
							from `v0_water` group by `v0_water`.`Apt`,`v0_water`.`Year`,`v0_water`.`Week`;

CREATE OR REPLACE VIEW Water_Daily 
							AS select `v0_water`.`Apt` AS `Apt`,
                            Max(`v0_water`.`Hot_Water`) - Min(`v0_water`.`Hot_Water`) AS `Hot_Water`,
                            Max(`v0_water`.`Total_Water`) - Min(`v0_water`.`Total_Water`) AS `Total_Water`,
							`v0_water`.`Date` AS `Date`
							from `v0_water` group by `v0_water`.`Apt`,`v0_water`.`Date`;							
												
							
CREATE OR REPLACE VIEW Water_Hourly
			 	AS	select date_format(ts,'%Y-%m-%d:%H') As TS,apt,
				Max(`hot`) - Min(`hot`) AS `Hot_Water`,
                Max(`total`) - Min(`total`) AS `Total_Water`
				from water
				group by apt,
				date_format(ts,'%Y-%m-%d:%H');	
							
