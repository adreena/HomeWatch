CREATE OR REPLACE VIEW Heat_Flux_Yearly 
							AS select `v0_heat_flux`.`Apt` AS `Apt`,
                            avg(`v0_heat_flux`.`stud`) AS `Stud`,
							avg(`v0_heat_flux`.`insulation`) AS `Insulation`,
							`v0_heat_flux`.`Year` AS `Year` 
							from `v0_heat_flux` group by `v0_heat_flux`.`Apt`,`v0_heat_flux`.`Year`;

CREATE OR REPLACE VIEW Heat_Flux_Monthly 
							AS select `v0_heat_flux`.`Apt` AS `Apt`,
                               avg(`v0_heat_flux`.`stud`) AS `Stud`,
							avg(`v0_heat_flux`.`insulation`) AS `Insulation`,
							`v0_heat_flux`.`Year` AS `Year`,
							`v0_heat_flux`.`Month` AS `Month`
							from `v0_heat_flux` group by `v0_heat_flux`.`Apt`,`v0_heat_flux`.`Year`,`v0_heat_flux`.`month`;	
							
CREATE OR REPLACE VIEW Heat_Flux_Weekly 
							AS select `v0_heat_flux`.`Apt` AS `Apt`,
                              avg(`v0_heat_flux`.`stud`) AS `Stud`,
							avg(`v0_heat_flux`.`insulation`) AS `Insulation`,
							`v0_heat_flux`.`Year` AS `Year`, 
							`v0_heat_flux`.`Week` AS `Week`
							from `v0_heat_flux` group by `v0_heat_flux`.`Apt`,`v0_heat_flux`.`Year`,`v0_heat_flux`.`Week`;

CREATE OR REPLACE VIEW Heat_Flux_Daily 
							AS select `v0_heat_flux`.`Apt` AS `Apt`,
                                avg(`v0_heat_flux`.`stud`) AS `Stud`,
							avg(`v0_heat_flux`.`insulation`) AS `Insulation`,
							`v0_heat_flux`.`Date` AS `Date`
							from `v0_heat_flux` group by `v0_heat_flux`.`Apt`,`v0_heat_flux`.`Date`;							


CREATE OR REPLACE VIEW Heat_Flux_Hourly

						AS	select date_format(ts,'%Y-%m-%d:%H') As TS,apt,
						avg(`stud`) AS `Stud`,
						avg(`insulation`) AS `Insulation`
						from heat_flux
						group by apt,
						date_format(ts,'%Y-%m-%d:%H');	
							
