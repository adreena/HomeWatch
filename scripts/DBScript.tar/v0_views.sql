CREATE OR REPLACE VIEW `v0_air` AS select `air`.`apt` AS `Apt`,
                               cast(`air`.`ts` as date) AS `Date`,
							   year(`air`.`ts`) AS `Year`,month(`air`.`ts`) AS `Month`,
							   dayofmonth(`air`.`ts`) AS `Day`,
							   hour(`air`.`ts`) AS `Hour`,
							   week(`air`.`ts`,0) AS `Week`,
							   dayofweek(`air`.`ts`)-1 AS `Day of Week`,
							   dayname(`air`.`ts`) AS `Day Name`,
							   `air`.`co2` AS `CO2`,`air`.`rh` AS `Relative Humidity`,
							   `air`.`temperature` AS `Temperature` 
							   from `air`;
							   
	
                                 
							   
CREATE OR REPLACE VIEW `v0_el_energy` AS select `el_energy`.`apt` AS `Apt`,
                               cast(`el_energy`.`ts` as date) AS `Date`,
							   year(`el_energy`.`ts`) AS `Year`,month(`el_energy`.`ts`) AS `Month`,
							   dayofmonth(`el_energy`.`ts`) AS `Day`,
							   hour(`el_energy`.`ts`) AS `Hour`,
							   week(`el_energy`.`ts`,0) AS `Week`,
							   dayofweek(`el_energy`.`ts`)-1 AS `Day of Week`,
							   dayname(`el_energy`.`ts`) AS `Day Name`,
							   `el_energy`.`phase` AS `Phase`,
							   `el_energy`.`ch1` AS `Ch1`,
							   `el_energy`.`ch2` AS `Ch2`,
							   `el_energy`.`aux1` AS `AUX1`,
							   `el_energy`.`aux2` AS `AUX2`, 
							   `el_energy`.`aux3` AS `AUX3`,
							   `el_energy`.`aux4` AS `AUX4`,
							   `el_energy`.`aux5` AS `AUX5`
							   from `el_energy`;
 
							CREATE OR REPLACE VIEW `v0_water` AS select `water`.`apt` AS `Apt`,
                               cast(`water`.`ts` as date) AS `Date`,
							   year(`water`.`ts`) AS `Year`,month(`water`.`ts`) AS `Month`,
							   dayofmonth(`water`.`ts`) AS `Day`,
							   hour(`water`.`ts`) AS `Hour`,
							   week(`water`.`ts`,0) AS `Week`,
							   dayofweek(`water`.`ts`)-1 AS `Day of Week`,
							   dayname(`water`.`ts`) AS `Day Name`,
							   `water`.`hot` AS `Hot_Water`,`water`.`total` AS `Total_Water`
							   from `water`;

							   CREATE OR REPLACE VIEW `v0_heat_flux` AS select `heat_flux`.`apt` AS `Apt`,
                               cast(`heat_flux`.`ts` as date) AS `Date`,
							   year(`heat_flux`.`ts`) AS `Year`,month(`heat_flux`.`ts`) AS `Month`,
							   dayofmonth(`heat_flux`.`ts`) AS `Day`,
							   hour(`heat_flux`.`ts`) AS `Hour`,
							   week(`heat_flux`.`ts`,0) AS `Week`,
							   dayofweek(`heat_flux`.`ts`)-1 AS `Day of Week`,
							   dayname(`heat_flux`.`ts`) AS `Day Name`,
							   `heat_flux`.`stud` AS `Stud`,`heat_flux`.`insulation` AS `Insulation`
							   from heat_flux;


							      CREATE OR REPLACE VIEW `v0_Heating` AS select `heating`.`apt` AS `Apt`,
                               cast(`heating`.`ts` as date) AS `Date`,
							   year(`heating`.`ts`) AS `Year`,month(`heating`.`ts`) AS `Month`,
							   dayofmonth(`heating`.`ts`) AS `Day`,
							   hour(`heating`.`ts`) AS `Hour`,
							   week(`heating`.`ts`,0) AS `Week`,
							   dayofweek(`heating`.`ts`)-1 AS `Day of Week`,
							   dayname(`heating`.`ts`) AS `Day Name`,
							   `heating`.`total_energy` AS `Total_Energy`,`heating`.`total_vol` AS `Total_Volume`,
							   `heating`.`total_mass` AS `Total_Mass`,`heating`.`cur_flow` AS `Current_Flow`,
							   `heating`.`cur_t1` AS `Current_Temperature_1`,
							   `heating`.`cur_t2` AS `Current_Temperature_2`
							   from heating;