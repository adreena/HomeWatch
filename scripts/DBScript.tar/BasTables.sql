DROP TABLE IF EXISTS temp_minute;
CREATE table temp_minute
SELECT date_format(ts,'%Y-%m-%d %H:%i') as ts,
avg(t1) as T1,
avg(t2) as T2,
avg(t3) as T3,
avg(t4) as T4,
avg(t5) as T5,
avg(t6) as T6,
avg(t7) as T7,
avg(t8) as T8,
avg(t9) as T9,
avg(t12) as T12,
avg(t13) as T13
from bas_temp_extra
group by
date_format(ts,'%Y-%m-%d %H:%i');

DROP TABLE IF EXISTS flow_minute;
CREATE table flow_minute
SELECT date_format(ts,'%Y-%m-%d %H:%i') as ts,
avg(flow1) as Flow1,
avg(flow2) as Flow2,
avg(flow3) as Flow3,
avg(flow4_1) as Flow4_1,
avg(flow4_2) as Flow4_2,
avg(flow5_1) as Flow5_1,
avg(flow5_2) as Flow5_2,
avg(flow5_3) as Flow5_3,
avg(flow5_4) as Flow5_4,
avg(flow6) as Flow6
from bas_flows
group by
date_format(ts,'%Y-%m-%d %H:%i');

DROP TABLE IF EXISTS boiler_loop_minute;
Create table boiler_loop_minute 
Select date_format(ts,'%Y-%m-%d %H:%i') as ts,
building,
AVG(AI_T15_Blr2_Supply) as T15,
AVG(AI_T14_Blr1_Supply) as T14,
AVG(BO_Blr_1_Enable) as BLR1,
AVG(BO_Blr_2_Enable) as BLR2,
AVG(AV_Tank_10_Setpoint) as TANK10,
AVG(AV_T10_Temp) as T10,
AVG(AI_T04_Outside_Air) as AIRT04
from bas_boiler_loop
group by
building, date_format(ts,'%Y-%m-%d %H:%i');

DROP TABLE IF EXISTS solar_minute;
Create table solar_minute 
Select date_format(ts,'%Y-%m-%d %H:%i') as ts,
building,
avg(BO_SHTS_Solar_EN) as T,
avg(`AI_T03_Solar_SupTemp2`) as SupTemp2,
avg(`AI_R05_Solar_SupPres`) as SupPres,
avg(`AI_T03_Solar_SupTemp1`) as SupTemp1,
avg(`AI_T03_Solar_SupTemp`) as SupTemp,
avg(`AI_R06_Solar_RetPres`) as RetPres,
avg(`AI_T04_Outside_Air`) as AirTemp
from bas_solar
group by
building, date_format(ts,'%Y-%m-%d %H:%i');


DROP TABLE IF EXISTS `COPCal`;
CREATE TABLE IF NOT EXISTS `COPCal` (
  `COP1` float DEFAULT NULL,
  `COP2` float DEFAULT NULL,
  `COP3` float DEFAULT NULL
);



DROP TABLE IF EXISTS `anaylze`;
CREATE TABLE IF NOT EXISTS `anaylze` (
  `COP1` float DEFAULT NULL,
  `COP2` float DEFAULT NULL,
  `COP3` float NOT NULL,
  `P11-P110` float DEFAULT NULL,
  `P12-P120` float DEFAULT NULL,
  `HPx1-HPx10` float DEFAULT NULL,
  `HPx2-HPx20` float DEFAULT NULL,
  `HPx3-HPx30` float DEFAULT NULL,
  `HPx4HPx40` float DEFAULT NULL,
  `Hours` float DEFAULT NULL,
  `NUM1` float DEFAULT NULL,
  `NUM2` float DEFAULT NULL,
  `NUM3` float DEFAULT NULL,
  `DOM1` float DEFAULT NULL,
  `DOM2` float DEFAULT NULL,
  `DOM3` float DEFAULT NULL,
  `P7_1` float DEFAULT NULL,
  `P8` float DEFAULT NULL,
  `P2_1` float DEFAULT NULL,
  `P2_2` float DEFAULT NULL,
  `P2_3` float DEFAULT NULL,
  `P2_4` float DEFAULT NULL,
  `P4_1` float DEFAULT NULL,
  `P4_2` float DEFAULT NULL,
  `BLR_1` float DEFAULT NULL,
  `BLR_2` float DEFAULT NULL,
  `P3_1` float DEFAULT NULL,
  `P3_2` float DEFAULT NULL,
  `SHTS` float DEFAULT NULL
);



Alter table temp_minute add constraint Primary Key ts(ts);
Alter table flow_minute add constraint Primary Key ts(ts);
Alter table solar_minute add constraint Primary Key ts(ts,building);
Alter table boiler_loop_minute add constraint Primary Key ts(ts,building);

