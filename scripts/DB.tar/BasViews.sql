Create or Replace view v0_energy
As Select a.ts,a.t,a.building,
b.Flow1,
b.Flow2,
b.Flow3,
b.Flow4_1,
b.Flow4_2,
b.Flow5_1,
b.Flow5_2,
b.Flow5_3,
b.Flow5_4,
b.Flow6,
c.T1,
c.T3,
c.T4,
c.T5,
c.T6,
c.T7,
c.T8,
c.T9,
c.T12,
c.T13,
d.T14,
d.T15
from solar_minute a,
flow_minute b,
temp_minute c,
boiler_loop_minute d
where a.ts = b.ts and a.ts = c.ts and a.ts = d.ts;


Create or Replace view Energy_Minute
As Select ts,building,
Date(ts) AS `Date`,
year(ts) AS `Year`,month(ts)AS `Month`,
dayofmonth(ts) AS `Day`,
hour(ts) AS `Hour`,
minute(ts) As 'Minute',
week(ts) AS `Week`,
(dayofweek(ts) - 1) AS `Day of Week`,
dayname(ts) AS `Day Name`,
(0.000001*.001*4.00*971.68*flow3*T*(T5-T4)) as 'Energy1',
(0.000001*.001*4.00*971.68*flow6*T*(T12-T13)) as 'Energy2',
(0.000001*.001*4.00*971.68*flow2*T*(T9-T8)) as 'Energy3',
(0.000001*.001*3.90*1016.98*(flow5_1+flow5_2+flow5_3+flow5_4)*T*(T3-T1)) as 'Energy4',
(0.000001*.001*3.90*1016.98*flow4_1*T*(T14-T1)) as 'Energy5',
(0.000001*.001*3.90*1016.98*flow4_2*T*(T15-T1)) as 'Energy6',
(0.000001*.001*3.90*1016.98*flow1*T*(T6-T7)) as 'Energy7'
from v0_energy;