DROP TABLE IF EXISTS `Equations`,`Constants`,`Alerts`,`User_Equations`,`User_Constants`,`User_Alerts`;

CREATE TABLE IF NOT EXISTS `Equations` (
  `Equation_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `Value` varchar(255) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Type` varchar(64) NOT NULL,
  PRIMARY KEY (`Equation_ID`)
);

INSERT INTO `Equations` (`Equation_ID`, `Name`, `Value`, `Description`, `Type`) VALUES
(5, 'ColdWater', '$water_total$ - $water_hot$', 'Cold water usage', ''),
(6, 'TotalElectricity', '$elec_ch1$', '', ''),
(7, 'HeatLoss', '$heatflux_stud$ + $heatflux_insul$', '', '');

CREATE TABLE IF NOT EXISTS `Constants` (
  `Constant_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `Value` double NOT NULL,
  `Description` varchar(255) NOT NULL,
  PRIMARY KEY (`Constant_ID`)
);

CREATE TABLE IF NOT EXISTS `Alerts` (
  `Alert_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `Value` varchar(255) NOT NULL,
  `Description` varchar(255) NOT NULL,
  PRIMARY KEY (`Alert_ID`)
);

INSERT INTO `Alerts` (`Alert_ID`, `Name`, `Value`, `Description`) VALUES
(9, 'co2_alert', '$air_co2$ < 1000', 'indoor air quality');

CREATE TABLE IF NOT EXISTS `User_Equations` (
  `User_ID` int(11) NOT NULL,
  `Equation_ID` int(11) NOT NULL,
  PRIMARY KEY (`User_ID`, `Equation_ID`),
  FOREIGN KEY (`User_ID`) REFERENCES Users(`User_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (`Equation_ID`) REFERENCES Equations(`Equation_ID`) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS `User_Constants` (
  `User_ID` int(11) NOT NULL,
  `Constant_ID` int(11) NOT NULL,
  PRIMARY KEY (`User_ID`, `Constant_ID`),
  FOREIGN KEY (`User_ID`) REFERENCES Users(`User_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (`Constant_ID`) REFERENCES Constants(`Constant_ID`) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS `User_Alerts` (
  `User_ID` int(11) NOT NULL,
  `Alert_ID` int(11) NOT NULL,
  PRIMARY KEY (`User_ID`, `Alert_ID`),
  FOREIGN KEY (`User_ID`) REFERENCES Users(`User_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (`Alert_ID`) REFERENCES Alerts(`Alert_ID`) ON DELETE CASCADE ON UPDATE CASCADE
);
