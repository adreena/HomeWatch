CREATE OR REPLACE VIEW Air_Yearly 
							AS select `v0_air`.`Apt` AS `Apt`,
                            avg(`v0_air`.`Temperature`) AS `Temperature`,
							avg(`v0_air`.`Relative Humidity`) AS `Relative_Humidity`,
							avg(`v0_air`.`CO2`) AS `CO2`,
							`v0_air`.`Year` AS `Year` 
							from `v0_air` group by `v0_air`.`Apt`,`v0_air`.`Year`;

CREATE OR REPLACE VIEW Air_Monthly 
							AS select `v0_air`.`Apt` AS `Apt`,
                            avg(`v0_air`.`Temperature`) AS `Temperature`,
							avg(`v0_air`.`Relative Humidity`) AS `Relative_Humidity`,
							avg(`v0_air`.`CO2`) AS `CO2`,
							`v0_air`.`Year` AS `Year`,
							`v0_air`.`Month` AS `Month`
							from `v0_air` group by `v0_air`.`Apt`,`v0_air`.`Year`,`v0_air`.`month`;	
							
CREATE OR REPLACE VIEW Air_Weekly 
							AS select `v0_air`.`Apt` AS `Apt`,
                            avg(`v0_air`.`Temperature`) AS `Temperature`,
							avg(`v0_air`.`Relative Humidity`) AS `Relative_Humidity`,
							avg(`v0_air`.`CO2`) AS `CO2`,
							`v0_air`.`Year` AS `Year`, 
							`v0_air`.`Week` AS `Week`
							from `v0_air` group by `v0_air`.`Apt`,`v0_air`.`Year`,`v0_air`.`Week`;

CREATE OR REPLACE VIEW Air_Daily 
							AS select `v0_air`.`Apt` AS `Apt`,
                            avg(`v0_air`.`Temperature`) AS `Temperature`,
							avg(`v0_air`.`Relative Humidity`) AS `Relative_Humidity`,
							avg(`v0_air`.`CO2`) AS `CO2`,
							`v0_air`.`Date` AS `Date`
							from `v0_air` group by `v0_air`.`Apt`,`v0_air`.`Date`;							

CREATE OR REPLACE VIEW Air_Hourly
				AS	select date_format(ts,'%Y-%m-%d:%H') As TS,apt,
				AVG(CO2) as "CO2",
			    AVG(`rh`) AS `Relative_Humidity`,
				AVG(temperature) AS `Temperature` 
				from air
				group by apt,
				date_format(ts,'%Y-%m-%d:%H');	
	

					
							

							
