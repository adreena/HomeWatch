
CREATE OR REPLACE VIEW El_Energy_Yearly 

                            AS select `v0_el_energy`.`Apt` AS `Apt`,
							`v0_el_energy`.`Phase` AS `Phase`,
							Max(`v0_el_energy`.`Ch1`) - Min(`v0_el_energy`.`Ch1`) AS `Ch1`,
							Max(`v0_el_energy`.`Ch2`) - Min(`v0_el_energy`.`Ch2`) AS `Ch2`,
							Max(`v0_el_energy`.`AUX1`) - Min(`v0_el_energy`.`AUX1`) AS `AUX1`,
							Max(`v0_el_energy`.`AUX2`) - Min(`v0_el_energy`.`AUX2`) AS `AUX2`,
							Max(`v0_el_energy`.`AUX3`) - Min(`v0_el_energy`.`AUX3`) AS `AUX3`,
							Max(`v0_el_energy`.`AUX4`) - Min(`v0_el_energy`.`AUX4`) AS `AUX4`,
							Max(`v0_el_energy`.`AUX5`) - Min(`v0_el_energy`.`AUX5`) AS `AUX5`,
							`v0_el_energy`.`Year` AS `Year` 
							from `v0_el_energy` group by `v0_el_energy`.`Apt`,`v0_el_energy`.`Phase`,`v0_el_energy`.`Year`;

CREATE OR REPLACE VIEW El_Energy_Monthly 
							AS  select `v0_el_energy`.`Apt` AS `Apt`,
							`v0_el_energy`.`Phase` AS `Phase`,
								Max(`v0_el_energy`.`Ch1`) - Min(`v0_el_energy`.`Ch1`) AS `Ch1`,
							Max(`v0_el_energy`.`Ch2`) - Min(`v0_el_energy`.`Ch2`) AS `Ch2`,
							Max(`v0_el_energy`.`AUX1`) - Min(`v0_el_energy`.`AUX1`) AS `AUX1`,
							Max(`v0_el_energy`.`AUX2`) - Min(`v0_el_energy`.`AUX2`) AS `AUX2`,
							Max(`v0_el_energy`.`AUX3`) - Min(`v0_el_energy`.`AUX3`) AS `AUX3`,
							Max(`v0_el_energy`.`AUX4`) - Min(`v0_el_energy`.`AUX4`) AS `AUX4`,
							Max(`v0_el_energy`.`AUX5`) - Min(`v0_el_energy`.`AUX5`) AS `AUX5`,
							`v0_el_energy`.`Year` AS `Year`,
							`v0_el_energy`.`Month` AS `Month`
							from `v0_el_energy` group by `v0_el_energy`.`Apt`,`v0_el_energy`.`Phase`,`v0_el_energy`.`Year`,`v0_el_energy`.`month`;	
							
CREATE OR REPLACE VIEW El_Energy_Weekly 
							AS select `v0_el_energy`.`Apt` AS `Apt`,
							`v0_el_energy`.`Phase` AS `Phase`,
								Max(`v0_el_energy`.`Ch1`) - Min(`v0_el_energy`.`Ch1`) AS `Ch1`,
							Max(`v0_el_energy`.`Ch2`) - Min(`v0_el_energy`.`Ch2`) AS `Ch2`,
							Max(`v0_el_energy`.`AUX1`) - Min(`v0_el_energy`.`AUX1`) AS `AUX1`,
							Max(`v0_el_energy`.`AUX2`) - Min(`v0_el_energy`.`AUX2`) AS `AUX2`,
							Max(`v0_el_energy`.`AUX3`) - Min(`v0_el_energy`.`AUX3`) AS `AUX3`,
							Max(`v0_el_energy`.`AUX4`) - Min(`v0_el_energy`.`AUX4`) AS `AUX4`,
							Max(`v0_el_energy`.`AUX5`) - Min(`v0_el_energy`.`AUX5`) AS `AUX5`,
							`v0_el_energy`.`Year` AS `Year`, 
							`v0_el_energy`.`Week` AS `Week`
							from `v0_el_energy` group by `v0_el_energy`.`Apt`,`v0_el_energy`.`Phase`,`v0_el_energy`.`Year`,`v0_el_energy`.`Week`;

CREATE OR REPLACE VIEW El_Energy_Daily 
							AS select `v0_el_energy`.`Apt` AS `Apt`,`v0_el_energy`.`Phase` AS `Phase`,
							Max(`v0_el_energy`.`Ch1`) - Min(`v0_el_energy`.`Ch1`) AS `Ch1`,
							Max(`v0_el_energy`.`Ch2`) - Min(`v0_el_energy`.`Ch2`) AS `Ch2`,
							Max(`v0_el_energy`.`AUX1`) - Min(`v0_el_energy`.`AUX1`) AS `AUX1`,
							Max(`v0_el_energy`.`AUX2`) - Min(`v0_el_energy`.`AUX2`) AS `AUX2`,
							Max(`v0_el_energy`.`AUX3`) - Min(`v0_el_energy`.`AUX3`) AS `AUX3`,
							Max(`v0_el_energy`.`AUX4`) - Min(`v0_el_energy`.`AUX4`) AS `AUX4`,
							Max(`v0_el_energy`.`AUX5`) - Min(`v0_el_energy`.`AUX5`) AS `AUX5`,
							`v0_el_energy`.`Date` AS `Date`
							from `v0_el_energy` group by `v0_el_energy`.`Apt`,`v0_el_energy`.`Phase`,`v0_el_energy`.`Date`;							


CREATE OR REPLACE VIEW El_Energy_Hourly
AS select date_format(ts,'%Y-%m-%d %H') As TS, apt,phase,
	Max(`ch1`) - Min(`ch2`) AS `Ch1`,
	Max(`ch2`) - Min(`ch2`) AS `Ch2`,
	Max(`aux1`) - Min(`aux1`) AS `AUX1`,
	Max(`aux2`) - Min(`aux2`) AS `AUX2`,
	Max(`aux3`) - Min(`aux3`) AS `AUX3`,
	Max(`aux4`) - Min(`aux4`) AS `AUX4`,
	Max(`aux5`) - Min(`aux5`) AS `AUX5`
	from el_energy
		group by apt,phase,
		date_format(ts,'%Y-%m-%d %H');
							