
CREATE OR REPLACE VIEW Heating_Yearly 
							AS select `v0_Heating`.`Apt` AS `Apt`,
							Max(`v0_Heating`.`Total_Energy`) - Min(`v0_Heating`.`Total_Energy`) AS `Total_Energy`,
							Max(`v0_Heating`.`Total_Volume`) - Min(`v0_Heating`.`Total_Volume`) AS `Total_Volume`,
							Max(  `v0_Heating`.`Total_Mass`) - Min(  `v0_Heating`.`Total_Mass`) AS `Total_Mass`,
							`v0_Heating`.`Year` AS `Year` 
							from `v0_Heating` group by `v0_Heating`.`Apt`,`v0_Heating`.`Year`;
							
CREATE OR REPLACE VIEW Heating_Water_Yearly 
							AS select `v0_Heating`.`Apt` AS `Apt`,
                            avg(`v0_Heating`.`Current_Flow`) AS `Current_Flow`,
							avg(`v0_Heating`.`Current_Temperature_1` )AS `Current_Temperature_1`,
							avg( `v0_Heating`.`Current_Temperature_2`) AS `Current_Temperature_2`,
							`v0_Heating`.`Year` AS `Year` 
							from `v0_Heating`
							group by `v0_Heating`.`Apt`,`v0_Heating`.`Year`
							Having avg(`v0_Heating`.`Current_Flow`)>0;
							
							
CREATE OR REPLACE VIEW Heating_Monthly 
							AS select `v0_Heating`.`Apt` AS `Apt`,
							Max(`v0_Heating`.`Total_Energy`) - Min(`v0_Heating`.`Total_Energy`) AS `Total_Energy`,
							Max(`v0_Heating`.`Total_Volume`) - Min(`v0_Heating`.`Total_Volume`) AS `Total_Volume`,
							Max(  `v0_Heating`.`Total_Mass`) - Min(  `v0_Heating`.`Total_Mass`) AS `Total_Mass`,
							`v0_Heating`.`Year` AS `Year`,
							`v0_Heating`.`Month` AS `Month`
							from `v0_Heating` group by `v0_Heating`.`Apt`,`v0_Heating`.`Year`,`v0_Heating`.`month`;	
							
CREATE OR REPLACE VIEW Heating_Water_Monthly 
							AS select `v0_Heating`.`Apt` AS `Apt`,
							 avg(`v0_Heating`.`Current_Flow`) AS `Current_Flow`,
							  avg(`v0_Heating`.`Current_Temperature_1` )AS `Current_Temperature_1`,
							  avg( `v0_Heating`.`Current_Temperature_2`) AS `Current_Temperature_2`,
							`v0_Heating`.`Year` AS `Year`,
							`v0_Heating`.`Month` AS `Month`
							from `v0_Heating` 
							group by `v0_Heating`.`Apt`,`v0_Heating`.`Year`,`v0_Heating`.`month`
                            Having avg(`v0_Heating`.`Current_Flow`)>0;							
							
							
CREATE OR REPLACE VIEW Heating_Weekly 
							AS select `v0_Heating`.`Apt` AS `Apt`,
							Max(`v0_Heating`.`Total_Energy`) - Min(`v0_Heating`.`Total_Energy`) AS `Total_Energy`,
							Max(`v0_Heating`.`Total_Volume`) - Min(`v0_Heating`.`Total_Volume`) AS `Total_Volume`,
							Max(  `v0_Heating`.`Total_Mass`) - Min(  `v0_Heating`.`Total_Mass`) AS `Total_Mass`,
							`v0_Heating`.`Year` AS `Year`, 
							`v0_Heating`.`Week` AS `Week`
							from `v0_Heating` 
							group by `v0_Heating`.`Apt`,`v0_Heating`.`Year`,`v0_Heating`.`Week`;
							
							
CREATE OR REPLACE VIEW Heating_Water_Weekly 
							AS select `v0_Heating`.`Apt` AS `Apt`,
							avg(`v0_Heating`.`Current_Flow`) AS `Current_Flow`,
							  avg(`v0_Heating`.`Current_Temperature_1` )AS `Current_Temperature_1`,
							  avg( `v0_Heating`.`Current_Temperature_2`) AS `Current_Temperature_2`,
							`v0_Heating`.`Year` AS `Year`, 
							`v0_Heating`.`Week` AS `Week`
							from `v0_Heating` 
							group by `v0_Heating`.`Apt`,`v0_Heating`.`Year`,`v0_Heating`.`Week`	
							Having avg(`v0_Heating`.`Current_Flow`)>0;
							
CREATE OR REPLACE VIEW Heating_Daily 
							AS select `v0_Heating`.`Apt` AS `Apt`,
							Max(`v0_Heating`.`Total_Energy`) - Min(`v0_Heating`.`Total_Energy`) AS `Total_Energy`,
							Max(`v0_Heating`.`Total_Volume`) - Min(`v0_Heating`.`Total_Volume`) AS `Total_Volume`,
							Max(  `v0_Heating`.`Total_Mass`) - Min(  `v0_Heating`.`Total_Mass`) AS `Total_Mass`,
							`v0_Heating`.`Date` AS `Date`
							from `v0_Heating` group by `v0_Heating`.`Apt`,`v0_Heating`.`Date`;	
							
CREATE OR REPLACE VIEW Heating_Water_Daily 
								AS select `v0_Heating`.`Apt` AS `Apt`,
							 avg(`v0_Heating`.`Current_Flow`) AS `Current_Flow`,
							  avg(`v0_Heating`.`Current_Temperature_1` )AS `Current_Temperature_1`,
							  avg( `v0_Heating`.`Current_Temperature_2`) AS `Current_Temperature_2`,
							`v0_Heating`.`Date` AS `Date`
							from `v0_Heating` group by `v0_Heating`.`Apt`,`v0_Heating`.`Year`
							Having avg(`v0_Heating`.`Current_Flow`)>0;
							
CREATE OR REPLACE VIEW Heating_Hourly
							AS	select date_format(ts,'%Y-%m-%d:%H') As TS,apt,
							Max(`total_energy`) - Min(`total_energy`) AS `Total_Energy`,
							Max(`total_vol`) - Min(`total_vol`) AS `Total_Volume`,
							Max(`total_mass`) - Min(`total_mass`) AS `Total_Mass`
							from heating
							group by apt,
							date_format(ts,'%Y-%m-%d:%H');								
							
							
							
							
CREATE OR REPLACE VIEW Heating_Water_Hourly
							AS	select date_format(ts,'%Y-%m-%d:%H') As TS,apt,
							avg(`cur_flow`) AS `Current_Flow`,
							  avg(`cur_t1` )AS `Current_Temperature_1`,
							  avg( `cur_t2`) AS `Current_Temperature_2`
							from heating
							group by apt,
							date_format(ts,'%Y-%m-%d:%H')
							Having avg(`cur_flow`)>0;
